import { Component } from '@angular/core';
import { WeatherService } from './weather.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'prova2';

  objects : Object[];
  constructor(private weatherService: WeatherService) {}

  ngOnInit() {
    this.getTempSp();
    
  }
  getTempSp(){
    this.weatherService.getAll("sp").subscribe(
      data => this.objects = data
    )
  }

  getTempRj(){
    this.weatherService.getAll("rj").subscribe(
      data => this.objects = data
    )
  }
}
